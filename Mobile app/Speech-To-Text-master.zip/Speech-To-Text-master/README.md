# Speech-To-Text
This repository contains a speech to text app which convert your voice to text and displays it on a text view 
It is an android app which created in android studio using java

![Speech To Text (1)](https://user-images.githubusercontent.com/64765400/96469320-f1625800-11e1-11eb-8050-5b781f62eae8.png)
